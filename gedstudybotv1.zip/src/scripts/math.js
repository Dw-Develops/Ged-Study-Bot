
    var mathQData = [
	{problem: 'The shirt you want to buy is 15% off from $32.50. How much will your shirt be?', a: 'A. $27.63', b:'B. $30.00', c: 'C. $17.50', d: 'D. $37.38', correctAnswer: 'A. $27.63' },
	{problem: 'If a=b(1/n) is equivalent to an=b then 43 is equivalent to:', a: 'A. 4(1/3)', b:'B. 64', c: 'C. 64(1/3)', d: 'D. 464', correctAnswer: 'C. 64(1/3)' },
	{problem: 'Solve: 5/8 – 1 /2', a: 'A. 1/4', b:'B. 1/8', c: 'C. 1/2', d: 'D. 10/16', correctAnswer: 'B. 1/8' },
	{problem: 'Simplify and combine like terms of the following expression: 3(2a+1) + 4a', a: 'A. 2a+1+12a', b:'B. 6a+3+4a', c: 'C. 10a+3', d: 'D. 7a+8a2', correctAnswer: 'C. 10a+3' },
	{problem: 'Denny has five kittens (K) that he wants to sell for $15.00 each. The cost to raise the kittens so far has been $10.00 each. What expression best represents how to find Denny’s total profit (P)?', a: 'A. P= 15K-10K', b:'B. P=5K-10K', c: 'C. P=15K-5K', d: 'D. P=5K-5K', correctAnswer: 'A. P= 15K-10K' }
	
	];
      console.log(mathQData[3]['problem']);
	  console.log(mathQData[3]['a']);
	  console.log(mathQData[3]['b']);
	  console.log(mathQData[3]['correctAnswer']);